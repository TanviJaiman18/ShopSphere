<%
response.sendRedirect("home.jsp");
%>
